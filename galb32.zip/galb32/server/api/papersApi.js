// var productCtrl = require('../controllers/content.controller.js');
// var express = require('express');
// var router = express.Router();
// let data;



// //get contact data
// router.post('/contact', function(req, res) {
//     let contactContent = productCtrl.getProducts(req.body);
//     console.log(contactContent);
// });



// module.exports = router;