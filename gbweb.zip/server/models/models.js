function Emtza(cust) {
    this.EmtzaNum = cust['EmtzaNum'];
    this.EmtzaDate = cust['EmtzaDate'];
    this.EmtzaHebDate = cust['EmtzaHebDate'];
}

module.exports.Emtza = Emtza;
